#!/bin/sh

# This file defines the user-specific environment variables
# which are expected by other engineering scripts,
# as well as any additional things you want to add.

# This file will be sourced before any files in the default directory.

# This file will not be updated when you update the ih-core brew formula.

export EDITOR="vim"
# Directory where you want to clone Legacy Grand Rounds repos,
# which are currently located in the ConsultingMD org.
export IH_HOME="/Users/rick.cobb/ih_home"
export GR_HOME="/Users/rick.cobb/ih_home"
export EMAIL_ADDRESS="rick.cobb@includedhealth.com"
export GITHUB_USER="cobbr2"
export GITHUB_EMAIL_ADDRESS="rick.cobb@includedhealth.com"
export FULL_NAME="Rick Cobb"
export IH_USERNAME="rick.cobb"
export GR_USERNAME="rick.cobb"
export JIRA_USERNAME="rick.cobb@includedhealth.com"
export AWS_DEFAULT_ROLE="dev"
